#!/bin/bash
make
./input-gen > points.in